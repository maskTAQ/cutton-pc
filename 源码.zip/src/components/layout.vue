<template>
  <div class="container">
    <div v-for="(area,areaIndex) in data.param" :key="areaIndex" class="area">
      <p class="area-title" v-if="area.title">{{area.title}}</p>

      <div class="area-content">
        <div
          :class="{'field-row':isShowField(field.visible)}"
          v-for="(field,fidldI) in area.data"
          :key="field.title||fidldI"
        >
          <template class v-if="isShowField(field.visible)">
            <p class="field-label" v-if="field.title">{{field.title}}</p>
            <div class="field-content">
              <template v-for="(component,componentI) in field.components">
                <input
                  class="input"
                  v-if="component.type === 'input'"
                  :key="component.content || componentI"
                  v-model="params[component.param]"
                  :placeholder="component.content"
                >
                <el-select
                  v-if="component.type === 'select'"
                  :key="component.label || componentI"
                  v-model="params[component.param]"
                  change="onChange(component.param)"
                  :placeholder="component.placeholder"
                >
                  <el-option
                    v-for="item in component.content"
                    :key="item"
                    :label="item"
                    :value="item"
                  ></el-option>
                </el-select>

                <el-radio-group
                  v-if="['radio','radiorect'].includes(component.type)"
                  :key="component.label || componentI"
                  v-model="params[component.param]"
                >
                  <el-radio v-for="item in component.content" :label="item" :key="item">{{item}}</el-radio>
                </el-radio-group>
                <el-checkbox-group
                  v-if="['check','checkcircle'].includes(component.type)"
                  :key="component.label || componentI"
                  v-model="params[component.param]"
                >
                  <el-checkbox v-for="item in component.content" :label="item" :key="item"></el-checkbox>
                </el-checkbox-group>
                <el-upload
                  v-if="component.type === 'input-file'"
                  :key="component.label || componentI"
                  :name="component.param"
                  class="upload-box"
                  :action="component.url"
                  :multiple="false"
                  :before-upload="beforeUpload"
                  :on-error="onUploadError"
                  :on-success="onUploadSuccess"
                >
                  <el-button size="small" type="text">点击上传</el-button>
                </el-upload>
                <p
                  v-if="component.type === 'text'"
                  :key="component.label || componentI"
                  :placeholder="component.placeholder"
                  class="text"
                >{{component.content}}</p>
              </template>
            </div>
          </template>
        </div>
      </div>
    </div>
    <el-button class="button" type="primary" :loading="false" @click="submit">下一步</el-button>
  </div>
</template>
<script>
import { getOfferList } from "@/apis";
export default {
  props: ["data", "onSubmit"],
  data() {
    return {
      params: {}
    };
  },
  created() {
    this.initParams();
  },

 
  computed: {
    a() {
      return this.params;
    }
  },
  methods: {
    initParams() {
      const p = {};
      this.data.param.forEach(area => {
        area.data.forEach(filed => {
          filed.components.forEach(component => {
            const { param, value, type } = component;
            if (type.includes("check")) {
              p[param] = value || [];
            } else {
              p[param] = value;
            }
          });
        });
      });
      this.params = p;
    },
    computedLayoutValue() {
      this.layout = this.data.param.map(area => {
        const data = area.data.filter(filed => {
          return this.isShowField(filed.visible);
        });
        return { ...area, data };
      });
    },
    isShowField(visible) {
      const { params } = this;
      let isVisible = true;
      if (typeof visible === "string") {
        if (visible.includes("=")) {
          const [key, value] = visible.split("=");
          if (Array.isArray(params[key])) {
            isVisible = params[key].some(item => item === value);
          } else {
            isVisible = params[key] === value;
          }
        }
        if (visible.includes("!=")) {
          const [key, value] = visible.split("!=");
          if (Array.isArray(params[key])) {
            isVisible = params[key].every(item => item !== value);
          } else {
            isVisible = params[key] !== value;
          }
        }
      }
      if (typeof visible === "boolean") {
        isVisible = visible;
      }
      return isVisible;
    },

    submit() {
      const { params, onSubmit } = this;
      onSubmit(params);
    },
   
    beforeUpload(file) {
      const { name = "", type } = file;
      const isJPG = name.includes("xls");

      if (!isJPG) {
        this.$message.error("只能上传xls格式的文件");
      }

      return isJPG;
    },
    onUploadError(...v){
      this.$message.error("上传失败");
    },
    onUploadSuccess(...v){
      this.$message.success("上传成功");
    },
  }
};
</script>
<style lang="scss" scoped>
@import "../platform.scss";
.container {
  height: 100%;
  padding-bottom: 100px;
  overflow: auto;
}
.area-title {
  //padding-left: 20px;
  height: 60px;
  line-height: 60px;
  font-size: 20px;
  color: #000;
}

.field-column {
  @extend .flex;
  flex-direction: column;

  background: #fff;
}
.field-row {
  height: 50px;
  @extend .flex;
  flex-direction: row;
  align-items: center;
  padding-right: 15px;
  //padding: 0 20px;
  @include borderD(bottom, 1px, solid, #ccc);
}
.field-title {
  font-size: 14px;
  color: #000;
}

.field-label {
  width: 70px;
  margin-right: 10px;
  font-size: 14px;
  color: #000;
}

.field-row-content {
  flex: 1;
  height: 100%;
  @extend .flex;
  flex-direction: row;
  align-items: center;
}

.field-content {
  flex: 1;
  @extend .flex;
  flex-direction: row;
  align-items: center;
}
.el-select {
  margin-right: 10px;
}
.input {
  flex: 1;
  height: 100%;
  border: none;
  outline: none;
}
.text {
  height: 100%;
  font-size: 14px;
  color: #000;
}
.upload-box {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.button {
  margin: 20px 0;
  width: 100%;
}
</style>
